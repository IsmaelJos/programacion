package es.ies.puerto.modelo.db;

import es.ies.puerto.exception.UsuarioException;
import es.ies.puerto.modelo.Alias;
import es.ies.puerto.modelo.Personajes;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Set;

public class OperacionesBdTest {
    OperacionesBd operacionesBd;
    String urlBd = "src/main/resources/personajesMal.db";
    String MESSAGE_ERROR = "NO SE HA OBTENIDO EL RESULTADO ESPERADO";
    Personajes personaje;
    Alias alias;
    @BeforeEach
    public void beforeEach() {
        try {
            personaje = new Personajes(3,"pepe","Hombre");
            alias = new Alias(3,1,"Pepe");
            operacionesBd = new OperacionesBd(urlBd);
        }catch (Exception exception) {
            Assertions.fail(exception.getMessage());
        }
    }

    @Test
    public void obtenerPersonajesAllTest() {
        try {
            Set<Personajes> lista = operacionesBd.obtenerPersonajes();
            Assertions.assertEquals(2, lista.size(), MESSAGE_ERROR);
        } catch (UsuarioException e) {
            Assertions.fail(e.getMessage());
        }
    }

    @Test
    public void obtenerPersonajeTest() {
        Personajes personaje = new Personajes(2);
        try {
            personaje = operacionesBd.obtenerPersonaje(personaje);
            Assertions.assertNotNull(personaje, MESSAGE_ERROR);
            Assertions.assertNotNull(personaje.getId(), MESSAGE_ERROR);
            Assertions.assertNotNull(personaje.getNombre(), MESSAGE_ERROR);
            Assertions.assertNotNull(personaje.getGenero(), MESSAGE_ERROR);
        } catch (UsuarioException e) {
            Assertions.fail(e.getMessage());
        }
    }

    @Test
    public void insertarEliminarPersonajeTest() {

        try {
            int numeroUsuarios = operacionesBd.obtenerPersonajes().size();
            operacionesBd.insertarPersonaje(personaje);
            Personajes personajeObtenido = operacionesBd.obtenerPersonaje(personaje);
            Assertions.assertEquals(personaje, personajeObtenido, MESSAGE_ERROR);
            operacionesBd.eliminarPersonaje(personajeObtenido);
            int numeroUsuariosFinal = operacionesBd.obtenerPersonajes().size();
            Assertions.assertEquals(numeroUsuarios, numeroUsuariosFinal, MESSAGE_ERROR);
        } catch (UsuarioException e) {
            Assertions.fail(e.getMessage());
        }
    }

    @Test
    public void actualizarPersonajeTest() {
        String generoUpdate = "Masculino";
        try {
            operacionesBd.insertarPersonaje(personaje);
            personaje.setGenero(generoUpdate);
            operacionesBd.actualizarPersonaje(personaje);
            Personajes usuarioEncontrado = operacionesBd.obtenerPersonaje(personaje);
            Assertions.assertEquals(personaje,usuarioEncontrado,MESSAGE_ERROR);
            Assertions.assertEquals(personaje.getGenero(),usuarioEncontrado.getGenero(),MESSAGE_ERROR);

            operacionesBd.eliminarPersonaje(usuarioEncontrado);
        }catch (Exception exception) {
            Assertions.fail(MESSAGE_ERROR+":"+exception.getMessage());
        }
    }

    @Test
    public void obtenerAliasAllTest() {
        try {
            Set<Alias> lista = operacionesBd.obtenerAlias();
            Assertions.assertEquals(2, lista.size(), MESSAGE_ERROR);
        } catch (UsuarioException e) {
            Assertions.fail(e.getMessage());
        }
    }

    @Test
    public void obtenerAliasTest() {
        Alias alias = new Alias(2);
        try {
            alias = operacionesBd.obtenerAlias(alias);
            Assertions.assertNotNull(alias, MESSAGE_ERROR);
            Assertions.assertNotNull(alias.getId(), MESSAGE_ERROR);
            Assertions.assertNotNull(alias.getPersonaje_id(), MESSAGE_ERROR);
            Assertions.assertNotNull(alias.getAlias(), MESSAGE_ERROR);
        } catch (UsuarioException e) {
            Assertions.fail(e.getMessage());
        }
    }
    @Test
    public void insertarEliminarAliasTest() {

        try {
            int numeroAlias = operacionesBd.obtenerAlias().size();
            operacionesBd.insertarAlias(alias);
            Alias aliasObtenido = operacionesBd.obtenerAlias(alias);
            Assertions.assertEquals(alias, aliasObtenido, MESSAGE_ERROR);
            operacionesBd.eliminarAlias(aliasObtenido);
            int numeroAliasFinal = operacionesBd.obtenerAlias().size();
            Assertions.assertEquals(numeroAlias, numeroAliasFinal, MESSAGE_ERROR);
        } catch (UsuarioException e) {
            Assertions.fail(e.getMessage());
        }
    }
    @Test
    public void actualizarAliasTest() {
        String aliasUpdate = "Juan";
        try {
            operacionesBd.insertarAlias(alias);
            alias.setAlias(aliasUpdate);
            operacionesBd.actualizarAlias(alias);
            Alias aliasEncontrado = operacionesBd.obtenerAlias(alias);
            Assertions.assertEquals(alias,aliasEncontrado,MESSAGE_ERROR);
            Assertions.assertEquals(alias.getAlias(),aliasEncontrado.getAlias(),MESSAGE_ERROR);

            operacionesBd.eliminarAlias(aliasEncontrado);
        }catch (Exception exception) {
            Assertions.fail(MESSAGE_ERROR+":"+exception.getMessage());
        }
    }
}
