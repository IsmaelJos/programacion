package persona;

public class Alumno extends Persona{

    public Alumno(String nombre, int edad, String dni) {
        super(nombre, edad, dni);
    }
}
