package vehiculos;

public class Vehiculo {
    String marca;
    String modelo;
    int precio;

    public Vehiculo(String marca, String modelo, int precio) {
        this.marca = marca;
        this.modelo = modelo;
        this.precio = precio;
    }
}
