package vehiculos;

public class Conductor {
    String nombre;
    int edad;
    String dni;

    public Conductor(){}

    public Conductor(String nombre, int edad, String dni) {
        this.nombre = nombre;
        this.edad = edad;
        this.dni = dni;
    }
}
