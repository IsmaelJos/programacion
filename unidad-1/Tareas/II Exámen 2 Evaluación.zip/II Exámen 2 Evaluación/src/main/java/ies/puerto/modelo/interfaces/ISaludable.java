package ies.puerto.modelo.interfaces;

public interface ISaludable {

    public int diasHastaCaducar();

    public boolean caducado();
}
