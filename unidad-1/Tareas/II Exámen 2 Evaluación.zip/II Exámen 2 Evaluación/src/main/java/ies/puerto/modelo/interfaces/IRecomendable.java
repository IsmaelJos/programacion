package ies.puerto.modelo.interfaces;

public interface IRecomendable {


    public boolean recomendarProducto();

    public int popularidad();
}
