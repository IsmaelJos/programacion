package ies.puerto.EJ6.interfaz;

public interface ITrabajador {
    public String trabajar();
}
