package ies.puerto.EJ1.abstracto;

public abstract class LecturaDatosAbstract {
    public abstract String lectura();
    public abstract String cierre();
    public abstract String apertura();
}

