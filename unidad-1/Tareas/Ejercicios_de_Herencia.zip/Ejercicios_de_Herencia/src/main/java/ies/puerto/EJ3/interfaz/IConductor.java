package ies.puerto.EJ3.interfaz;

public interface IConductor {
    public String arrancar();
    public String detener();
}
