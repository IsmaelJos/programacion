package ies.puerto.EJ2.impl;

import ies.puerto.EJ2.interfaz.IFormaGeometrica;

public class Rectangulo extends Cuadrado implements IFormaGeometrica {
    public Rectangulo(float base, float altura) {
        super(base, altura);
    }


}
