package ies.puerto.EJ4.abstracto;

public abstract class ConexionRed {
    public String conectar(){
        return "Se ha conectado";
    };
}
