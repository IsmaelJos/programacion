package ies.puerto.EJ4.interfaz;

public interface IConexionRed {
    public String conectar();
}
