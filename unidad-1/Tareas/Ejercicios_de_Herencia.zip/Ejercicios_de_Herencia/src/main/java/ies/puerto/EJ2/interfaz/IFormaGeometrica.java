package ies.puerto.EJ2.interfaz;

public interface IFormaGeometrica {
    float calcularArea();
}
