package ies.puerto.EJ1.interfaz;

public interface IReproductor {
    public String reproducir();
    public String detener();
}
