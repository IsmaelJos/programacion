package ies.puerto.EJ3.abstracto;

public abstract class Conductor {
    public String arrancar(){
        return "Arranca un conductor";
    };
    public String detener(){
        return "Detiene un conductor";
    };
}
