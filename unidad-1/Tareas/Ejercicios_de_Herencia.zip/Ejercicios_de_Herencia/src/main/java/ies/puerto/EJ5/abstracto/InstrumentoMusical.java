package ies.puerto.EJ5.abstracto;

public abstract class InstrumentoMusical {
    public String tocarNota(String nota){
        return null;
    };

    public String afinar() {
        return null;
    }
}
