package ies.puerto.EJ1.interfaz;

public interface ILecturaDatos {
    public String Lectura();
    public String Apertura();
    public String Cierre();
}
