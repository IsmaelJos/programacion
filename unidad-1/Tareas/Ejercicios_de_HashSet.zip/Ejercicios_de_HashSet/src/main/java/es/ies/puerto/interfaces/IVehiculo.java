package es.ies.puerto.interfaces;

public interface IVehiculo {
    int velocidadMaxima();

}
