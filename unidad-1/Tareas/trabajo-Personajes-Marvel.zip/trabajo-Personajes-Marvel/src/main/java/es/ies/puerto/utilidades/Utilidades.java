package es.ies.puerto.utilidades;

public class Utilidades {
    public final String DELIMITADOR =",";
}
