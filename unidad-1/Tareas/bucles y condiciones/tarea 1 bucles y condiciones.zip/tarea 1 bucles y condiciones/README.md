<div align="justify">


# Tarea 8 <a name="tarea8"></a>

## Descripción del ejercicio

Desarrolle un algoritmo que permita calcular Promedio de Notas; finaliza cuando N = 0.

## Diagrama de flujos

<div align="center">
    <img src="images/diagrama-flujo8.png"/> 
</div>

## Pseudocódigo

1. Inicio
2. Declaración de Variables:
N = 0, Promedio = 0, Acumula= 0
3. Hacer
4. Leer N
5. si N != 0
6. Cuenta = Cuenta + 1
7. Acumula = Acumula + N
8. fin si
9. Mientras N != 0
10. Promedio = Acumula/Cuenta
11. Imprimir “Promedio = ” + Promedio;
12. Fin


</div>
